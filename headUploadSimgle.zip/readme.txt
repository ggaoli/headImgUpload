server: 'http://192.168.212.110/fileCenter/fileUpload.sp?act=uploadSave&appId=00000001&caseId=00000014',
配这个路径就可以了，这个就是我本地的代理服务地址，在我们本机会有跨域问题，

